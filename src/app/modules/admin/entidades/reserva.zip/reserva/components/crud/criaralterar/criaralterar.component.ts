import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-criaralterar',
  templateUrl: './criaralterar.component.html',
  styleUrls: ['./criaralterar.component.scss']
})
export class CriaralterarComponent implements OnInit {

  formCriarAlterarReserva !: FormGroup;
  extras = ["Extra 1", "Extra 2", "Extra 3", "Extra 4", "Extra 5" ];


  constructor(private formBuilder: FormBuilder) { }

  ngOnInit(): void {
    this.formCriarAlterarReserva = this.formBuilder.group({
        restaurante : ['', Validators.required],
        seating : ['', Validators.required],
        dataReserva : ['', Validators.required],
        numAdultos : ['', Validators.required],
        numCrianca : ['', Validators.required],
        extras : ['', Validators.required],
        observacoes : ['',Validators.required]
    });
  }

  addReserva(){
    console.log("ADICIONAR UMA RESERVA");
    console.log(this.formCriarAlterarReserva.value);
  }

}
