import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-apagar',
  templateUrl: './apagar.component.html',
  styleUrls: ['./apagar.component.scss']
})
export class ApagarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
