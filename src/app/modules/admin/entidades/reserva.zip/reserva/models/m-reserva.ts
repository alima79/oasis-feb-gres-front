export class MReserva {
}
