import { MReserva } from './m-reserva';

describe('MReserva', () => {
  it('should create an instance', () => {
    expect(new MReserva()).toBeTruthy();
  });
});
